# Sample Shop — optional starter app for the observability labs

A deliberately small Python app you **may** use for the labs. Using it is optional:
if you prefer, build your own two-service app in any language. You score the same either way.

```
browser / k6  ──►  frontend (:8080)  ──►  orders-api (:8081)  ──►  Postgres (:5432)
```

| Service | What it does | Endpoints |
| --- | --- | --- |
| `frontend` | Customer-facing; places orders by calling orders-api | `GET /`, `GET /health`, `POST /checkout`, `GET /orders` |
| `orders-api` | Stores and lists orders (Postgres, or in-memory if no DB) | `GET /health`, `POST /orders`, `GET /orders`, `GET/POST /admin/fault` |

## What is (and is not) included

- **Included:** JSON logs to stdout, health endpoints, Dockerfiles, a Helm chart, docker-compose, a k6 load script, and fault injection.
- **Not included on purpose:** OpenTelemetry, Prometheus metrics, and `trace_id` in logs. Adding these is your job in Lab 3.

## Run it

**Option A — docker compose (quickest check):**

```bash
docker compose up --build
curl -X POST localhost:8080/checkout -H 'Content-Type: application/json' -d '{"item":"idli","quantity":2}'
curl localhost:8080/orders
```

**Option B — kind + Helm (what the labs use):**

```bash
docker build -t sample-shop/frontend:0.1.0 frontend
docker build -t sample-shop/orders-api:0.1.0 orders-api
kind load docker-image sample-shop/frontend:0.1.0 sample-shop/orders-api:0.1.0

# Point an ArgoCD Application at charts/sample-shop with values-dev.yaml (Lab 1),
# or for a quick manual test:
helm install shop charts/sample-shop -f charts/sample-shop/values-dev.yaml
kubectl port-forward svc/frontend 8080:8080
```

## Fault injection

Use these to create something to find in Lab 3 and to run the Lab 4 drills.

| Setting | Env var | Helm value | Effect |
| --- | --- | --- | --- |
| Delay | `DELAY_MS` | `ordersApi.fault.delayMs` | Extra latency added to a request |
| Delay share | `DELAY_PERCENT` | `ordersApi.fault.delayPercent` | % of requests that get the delay |
| Errors | `ERROR_PERCENT` | `ordersApi.fault.errorPercent` | % of requests that return HTTP 500 |

The GitOps way is to change the values in `values-dev.yaml` and commit. For a quick drill you can also change them live, without a redeploy:

```bash
kubectl port-forward svc/orders-api 8081:8081
curl -X POST localhost:8081/admin/fault -H 'Content-Type: application/json' \
     -d '{"delay_ms": 800, "delay_percent": 20}'
curl localhost:8081/admin/fault        # show current settings
```

Other easy drills: scale `frontend` to 0 (probe alert), scale `postgres` to 0 (DB alert and `orders-api /health` returns 503).

## Generate traffic

```bash
kubectl port-forward svc/frontend 8080:8080
k6 run -e BASE_URL=http://localhost:8080 loadtest/k6-checkout.js            # 10 minutes
k6 run -e BASE_URL=http://localhost:8080 -e DURATION=1m loadtest/k6-checkout.js
```

## Hints for Lab 3 (instrumentation)

- Auto-instrumentation is the fastest route: add `opentelemetry-distro` and `opentelemetry-exporter-otlp` to `requirements.txt`, run `opentelemetry-bootstrap -a install` in the Dockerfile, and start the app with `opentelemetry-instrument python app.py`. Flask, `requests` and `psycopg` are then traced automatically. The OpenTelemetry Operator's Python auto-instrumentation also works.
- Point the exporter at Alloy with `OTEL_EXPORTER_OTLP_ENDPOINT`, and set `OTEL_SERVICE_NAME` per service.
- For `trace_id` in logs, read the current span context in the `JsonFormatter` (`opentelemetry.trace.get_current_span().get_span_context()`) and add it to each log line.
- The app runs Flask's built-in threaded server, which is fine for a lab but not for production.
