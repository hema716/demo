{{- define "sample-shop.labels" -}}
app.kubernetes.io/part-of: sample-shop
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}
