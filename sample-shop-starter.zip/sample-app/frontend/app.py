"""frontend: the customer-facing service. Calls orders-api to place orders.

Deliberately NOT instrumented with OpenTelemetry - adding metrics, traces and
trace-correlated logs is the candidate's job in Lab 3.

Endpoints:
  GET  /          simple HTML page with a "Place order" button
  GET  /health    liveness/readiness + Blackbox probe target
  POST /checkout  places an order via orders-api (also accepts GET for easy curl/k6)
  GET  /orders    recent orders, fetched from orders-api
"""
import json
import logging
import os
import sys
import time
from datetime import datetime, timezone

import requests
from flask import Flask, jsonify, request

SERVICE = "frontend"
ORDERS_API_URL = os.getenv("ORDERS_API_URL", "http://localhost:8081")
TIMEOUT_S = float(os.getenv("ORDERS_API_TIMEOUT_S", "5"))


class JsonFormatter(logging.Formatter):
    def format(self, record):
        entry = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname.lower(),
            "service": SERVICE,
            "msg": record.getMessage(),
        }
        entry.update(getattr(record, "extra_fields", {}))
        return json.dumps(entry)


handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(JsonFormatter())
log = logging.getLogger(SERVICE)
log.addHandler(handler)
log.setLevel(os.getenv("LOG_LEVEL", "INFO").upper())
logging.getLogger("werkzeug").setLevel(logging.WARNING)


def info(msg, **fields):
    log.info(msg, extra={"extra_fields": fields})


def error(msg, **fields):
    log.error(msg, extra={"extra_fields": fields})


app = Flask(__name__)

PAGE = """<!doctype html><html><head><title>Sample Shop</title>
<style>body{font-family:sans-serif;max-width:560px;margin:40px auto}
button{padding:8px 16px}pre{background:#f4f4f4;padding:12px}</style></head>
<body><h1>Sample Shop</h1>
<p>Place an order to generate traffic through frontend &rarr; orders-api.</p>
<button onclick="order()">Place order</button>
<pre id="out">-</pre>
<script>
async function order(){
  const r = await fetch('/checkout',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({item:'masala-dosa',quantity:1})});
  document.getElementById('out').textContent = r.status + ' ' + await r.text();
}
</script></body></html>"""


@app.get("/")
def index():
    return PAGE


@app.get("/health")
def health():
    return jsonify(status="ok")


@app.route("/checkout", methods=["GET", "POST"])
def checkout():
    start = time.time()
    body = request.get_json(silent=True) or {}
    payload = {"item": body.get("item", "masala-dosa"), "quantity": body.get("quantity", 1)}
    try:
        resp = requests.post(f"{ORDERS_API_URL}/orders", json=payload, timeout=TIMEOUT_S)
    except requests.RequestException as exc:
        error("orders-api unreachable", error=str(exc),
              duration_ms=round((time.time() - start) * 1000, 1))
        return jsonify(error="orders service unavailable"), 502

    duration_ms = round((time.time() - start) * 1000, 1)
    if resp.status_code >= 400:
        error("checkout failed", upstream_status=resp.status_code, duration_ms=duration_ms)
        return jsonify(error="checkout failed", upstream_status=resp.status_code), 502

    order = resp.json()
    info("checkout ok", order_id=order.get("id"), duration_ms=duration_ms)
    return jsonify(status="ok", order=order), 200


@app.get("/orders")
def orders():
    try:
        resp = requests.get(f"{ORDERS_API_URL}/orders", timeout=TIMEOUT_S)
        return jsonify(resp.json()), resp.status_code
    except requests.RequestException as exc:
        error("orders-api unreachable", error=str(exc))
        return jsonify(error="orders service unavailable"), 502


if __name__ == "__main__":
    port = int(os.getenv("PORT", "8080"))
    info("starting", port=port, orders_api_url=ORDERS_API_URL)
    app.run(host="0.0.0.0", port=port, threaded=True)
