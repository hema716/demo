// Load generator for Lab 3 (and a starting point for the Lab 4 synthetic check).
// Run:  k6 run -e BASE_URL=http://localhost:8080 loadtest/k6-checkout.js
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  vus: 5,
  duration: __ENV.DURATION || '10m',
  thresholds: {
    http_req_failed: ['rate<0.05'],
    http_req_duration: ['p(95)<1000'],
  },
};

const BASE_URL = __ENV.BASE_URL || 'http://localhost:8080';

export default function () {
  const res = http.post(
    `${BASE_URL}/checkout`,
    JSON.stringify({ item: 'masala-dosa', quantity: 1 }),
    { headers: { 'Content-Type': 'application/json' } },
  );
  check(res, { 'checkout is 200': (r) => r.status === 200 });
  http.get(`${BASE_URL}/orders`);
  sleep(1);
}
