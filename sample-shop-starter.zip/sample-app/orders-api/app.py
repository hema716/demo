"""orders-api: stores and lists orders.

Deliberately NOT instrumented with OpenTelemetry - adding metrics, traces and
trace-correlated logs is the candidate's job in Lab 3.

Storage: Postgres when DATABASE_URL is set, otherwise in-memory.

Fault injection (for the labs and failure drills):
  env DELAY_MS        extra latency added to a request (default 0)
  env DELAY_PERCENT   % of requests that get the delay (default 0)
  env ERROR_PERCENT   % of requests that return HTTP 500 (default 0)
  POST /admin/fault   change the three values at runtime, e.g.
                      curl -X POST localhost:8081/admin/fault \
                        -H 'Content-Type: application/json' \
                        -d '{"delay_ms": 800, "delay_percent": 20}'
"""
import json
import logging
import os
import random
import sys
import threading
import time
import uuid
from datetime import datetime, timezone

from flask import Flask, jsonify, request

SERVICE = "orders-api"


class JsonFormatter(logging.Formatter):
    def format(self, record):
        entry = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname.lower(),
            "service": SERVICE,
            "msg": record.getMessage(),
        }
        entry.update(getattr(record, "extra_fields", {}))
        return json.dumps(entry)


handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(JsonFormatter())
log = logging.getLogger(SERVICE)
log.addHandler(handler)
log.setLevel(os.getenv("LOG_LEVEL", "INFO").upper())
logging.getLogger("werkzeug").setLevel(logging.WARNING)


def info(msg, **fields):
    log.info(msg, extra={"extra_fields": fields})


def error(msg, **fields):
    log.error(msg, extra={"extra_fields": fields})


fault = {
    "delay_ms": int(os.getenv("DELAY_MS", "0")),
    "delay_percent": int(os.getenv("DELAY_PERCENT", "0")),
    "error_percent": int(os.getenv("ERROR_PERCENT", "0")),
}


# ---------- storage ----------
class MemoryStore:
    def __init__(self):
        self._orders = []
        self._lock = threading.Lock()

    def ping(self):
        return True

    def add(self, order):
        with self._lock:
            self._orders.append(order)

    def list(self, limit=20):
        with self._lock:
            return list(reversed(self._orders[-limit:]))


class PostgresStore:
    def __init__(self, url):
        import psycopg  # imported only when Postgres is used

        self._psycopg = psycopg
        self._url = url
        with self._conn() as conn:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS orders (
                       id TEXT PRIMARY KEY, item TEXT NOT NULL,
                       quantity INT NOT NULL, created_at TIMESTAMPTZ NOT NULL)"""
            )

    def _conn(self):
        return self._psycopg.connect(self._url, connect_timeout=3, autocommit=True)

    def ping(self):
        with self._conn() as conn:
            conn.execute("SELECT 1")
        return True

    def add(self, order):
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO orders (id, item, quantity, created_at) VALUES (%s, %s, %s, %s)",
                (order["id"], order["item"], order["quantity"], order["created_at"]),
            )

    def list(self, limit=20):
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT id, item, quantity, created_at FROM orders ORDER BY created_at DESC LIMIT %s",
                (limit,),
            ).fetchall()
        return [
            {"id": r[0], "item": r[1], "quantity": r[2], "created_at": r[3].isoformat()}
            for r in rows
        ]


def make_store():
    url = os.getenv("DATABASE_URL")
    if not url:
        info("using in-memory storage")
        return MemoryStore()
    for attempt in range(1, 31):
        try:
            store = PostgresStore(url)
            info("connected to postgres")
            return store
        except Exception as exc:  # noqa: BLE001
            error("postgres not ready, retrying", attempt=attempt, error=str(exc))
            time.sleep(2)
    raise SystemExit("could not connect to postgres")


store = make_store()
app = Flask(__name__)


def apply_faults():
    if fault["delay_ms"] and random.randint(1, 100) <= fault["delay_percent"]:
        time.sleep(fault["delay_ms"] / 1000)
    if random.randint(1, 100) <= fault["error_percent"]:
        return True
    return False


@app.get("/health")
def health():
    try:
        store.ping()
        return jsonify(status="ok")
    except Exception as exc:  # noqa: BLE001
        error("health check failed", error=str(exc))
        return jsonify(status="db_unavailable"), 503


@app.post("/orders")
def create_order():
    start = time.time()
    body = request.get_json(silent=True) or {}
    item = body.get("item", "masala-dosa")
    quantity = int(body.get("quantity", 1))

    if apply_faults():
        error("injected failure", item=item)
        return jsonify(error="internal error"), 500

    order = {
        "id": str(uuid.uuid4()),
        "item": item,
        "quantity": quantity,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    try:
        store.add(order)
    except Exception as exc:  # noqa: BLE001
        error("failed to store order", error=str(exc))
        return jsonify(error="database error"), 503

    info(
        "order created",
        order_id=order["id"],
        item=item,
        quantity=quantity,
        duration_ms=round((time.time() - start) * 1000, 1),
    )
    return jsonify(order), 201


@app.get("/orders")
def list_orders():
    if apply_faults():
        return jsonify(error="internal error"), 500
    return jsonify(store.list())


@app.route("/admin/fault", methods=["GET", "POST"])
def set_fault():
    if request.method == "POST":
        body = request.get_json(silent=True) or {}
        for key in fault:
            if key in body:
                fault[key] = int(body[key])
        info("fault settings changed", **fault)
    return jsonify(fault)


if __name__ == "__main__":
    port = int(os.getenv("PORT", "8081"))
    info("starting", port=port)
    app.run(host="0.0.0.0", port=port, threaded=True)
